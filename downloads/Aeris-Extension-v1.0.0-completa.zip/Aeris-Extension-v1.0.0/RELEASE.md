# Aeris Extension 1.0.0 — Distribuição manual

Discreto e Eficiente. · by K&G Vision

Primeira versão numerada 1.0.0 para distribuição manual, derivada diretamente da RC2. Mantém as 16 ferramentas, 69 regras determinísticas, 30 frases e integração Ollama opcional. Não inclui novas permissões nem alterações na lógica das ferramentas. Manifest V3, versão numérica 1.0.0.

## Instalação e atualização

Extraia o ZIP de instalação em uma pasta local e selecione a pasta contendo `manifest.json` em Carregar sem compactação, no gerenciador de extensões (Chrome, Edge ou Opera). Para o ZIP completo, selecione a subpasta `extension`. Para atualizar uma instalação manual, substitua os arquivos da pasta da extensão e clique em Recarregar; confira a versão 1.0.0. Faça cópia manual dos textos de sessão que deseja preservar, pois a atualização pode limpar a sessão. Não desative proteções ou políticas administrativas. Não é CRX assinado nem publicação em loja.

## Evidências e limites

- O titular informou ter testado a RC2. Não foram fornecidos navegador, sistema, casos individuais ou relatório, portanto isso não equivale à validação integral de todos os navegadores.
- A versão 1.0.0 conserva o código JavaScript e as permissões da RC2; alterações limitadas à versão, documentação e empacotamento.
- 50 testes Node, verificação de sintaxe e construção determinística do pacote são os critérios automatizados desta entrega.
- Os testes nativos anteriores no ambiente de desenvolvimento foram bloqueados. Validação independente de Chrome, Edge, Opera, Ollama real, acessibilidade, desempenho, licença e requisitos das lojas continua pendente. Não se afirma certificação, estabilidade universal ou aprovação em loja. Use dados fictícios.

## Segurança do Autofill

A RC2 revalida candidatos na confirmação, rejeita duplicatas, campos substituídos e formulários com mais de 500 candidatos; confirmações recusadas não são reutilizáveis. Não envia formulários, não dispara cliques e não permite credenciais. Páginas podem observar valores inseridos.

## Validação manual

Use https://kgasil.github.io/aeris/extension-validation.html com dados inventados. Registre navegador, versão, sistema e casos aprovados. Confira a captura de seleção, sessão, clipboard, popup, permissões locais, Autofill e privacidade. Consulte PRIVACY.md.

## Licença

Distribuição gratuita para avaliação; a licença de redistribuição ainda deve ser definida pelo titular. Não há publicação nas lojas nesta entrega.
