# Aeris Extension — Discreto e Eficiente.

by K&G Vision · 1.0.0 · Distribuição manual

Primeira distribuição manual 1.0.0 Manifest V3 para Chromium, baseada na RC2. Gratuita, sem conta, anúncios, servidor próprio, telemetria ou conexão direta com o Desktop. Use dados fictícios nesta versão. Não é uma extensão publicada em loja.

## Instalar manualmente

1. Extraia o ZIP em uma pasta local.
2. Abra `chrome://extensions/` (Chrome), `edge://extensions/` (Edge) ou `opera://extensions/` (Opera).
3. Ative o modo desenvolvedor e selecione **Carregar sem compactação**. No ZIP completo, escolha a pasta `extension` que contém `manifest.json`; no ZIP de instalação, escolha diretamente a pasta extraída que contém esse arquivo.
4. Abra Aeris pelo menu de extensões. Se desejar, fixe o ícone na barra de ferramentas.
5. Clique em **Painel** para abrir a interface em uma aba. Capture, Autofill e consulta da aba atual só estão habilitados no popup; Research e Reading aceitam dados manuais no painel.

Não altere políticas administrativas ou proteções do navegador para instalar. Remova a extensão pela página de gerenciamento quando desejar.

## Ferramentas

| Ferramenta | Implementação inicial |
|---|---|
| Capture | Seleção explícita da página HTTP(S) atual, sem campos editáveis; limite de 12 mil caracteres |
| Text | Contagem e revisão determinística PT/EN/ES, prévia, lista de sugestões, confirmação e desfazer |
| Snippets | Até 30 textos de sessão, copiar e excluir |
| Checklist | Até 30 tarefas de sessão, conclusão e exclusão |
| Focus | Prazo local de 1–120 minutos, atualizado enquanto a interface estiver aberta |
| Calculator | Operações básicas, percentual e margem |
| Convert | Comprimento, massa, tempo, dados e temperatura |
| Link | Indicadores sintáticos de URL, sem visitar o endereço |
| Translate | Guia de 30 frases em português, inglês e espanhol |
| Page | Título e origem da aba atual; caminho opcional, sem query, fragmento ou credenciais |
| Research | Até 30 referências de sessão, com notas, filtro sem acentos, cópia e exclusão |
| Reading | Estatísticas e estimativa de leitura a 200 palavras/minuto; texto manual ou seleção explícita |
| Autofill | Prévia e confirmação de um campo vazio permitido em HTTPS, sem armazenar o valor |
| Expand | Quatro atalhos de texto prontos e até 20 personalizados por sessão, aplicação manual dentro do Aeris |
| Connect | Assistente, revisão e resumo com Ollama opcional em loopback; transferência manual por cópia |
| Privacy | Contagens de sessão, consulta e revogação da permissão local |

## Privacidade e limites

Permissões `activeTab`, `scripting` e `storage`. Nenhuma permissão de host obrigatória, script de conteúdo automático ou service worker. Connect solicita permissão de host opcional para 127.0.0.1, que pode permanecer concedida no navegador até revogação. `activeTab` e `scripting` são usados em consultas explícitas de aba e seleção, somente por clique. `storage.session` mantém checklist, snippets, referências, atalhos personalizados e prazo do Focus durante a sessão do navegador; não é armazenamento criptografado nem armazenamento persistente. Limpar sessão exige confirmação. Copiar usa Clipboard API após ação explícita, sujeito às permissões do navegador. A política CSP restringe conexões das páginas da extensão ao Ollama em http://127.0.0.1:11434; somente Connect inicia solicitações após autorização. Não há tradução livre, preenchimento global de formulários, alertas em segundo plano ou captura global. Não guarde informações sensíveis. O isolamento das páginas e a política CSP não equivalem a uma auditoria independente de segurança. Capture não deve ser utilizado para dados confidenciais, e a análise de links não é verificação de reputação.

## Validação

- `npm test` (Node 22): 50 testes unitários aprovados (incluindo DOM simulado e transporte HTTP simulado em Node). Sem dependências npm.
- `node --check extension/app.js`: sintaxe aprovada.
- `python tests/browser_smoke.py` (Playwright + Chromium): roteiro de integração real; execução bloqueada por política administrativa no ambiente de desenvolvimento. O teste abre a página da extensão, não testa o clique real da barra de ferramentas; Capture deve ser conferido manualmente.
- `python tests/ui_mock_smoke.py`: roteiro ampliado de interface com APIs simuladas, bloqueado por ERR_BLOCKED_BY_ADMINISTRATOR ao acessar a página de teste local. Não foi aprovado.

O usuário informou ter testado a RC2; navegador, sistema e resultados detalhados não foram informados. A validação nativa independente de Chrome/Edge/Opera permanece pendente. A extensão exige Chromium moderno com Manifest V3, storage.session e Web Locks. Não há certificação de compatibilidade com uma versão específica do navegador. Teste manualmente seleção, permissões, copiar, reabertura do popup, exclusão de sessão e comportamento em páginas restritas. Não use dados reais até completar a validação.

## Próximos passos

1. Validar instalação real e Capture, sessão, clipboard e painel nos três navegadores.
2. Intelligent Text: revisão determinística ampliada implementada; validar a interface nativa.
3. Connect: IA local opcional e transferência manual implementadas; validar servidor real e avaliar conexão direta com Desktop em etapa posterior.
4. Revisão de privacidade, acessibilidade, desempenho e requisitos das lojas.

Distribuição independente do Desktop publicado. Consulte RELEASE.md e PRIVACY.md. Não é uma publicação em loja.

## Novidades da a2

Page e Research removem parâmetros de consulta e fragmentos de URLs; por padrão guardam somente a origem (protocolo, host e porta). O caminho é opcional, pois pode conter identificadores ou informações privadas. Títulos e notas também podem conter dados privados: revise antes de copiar ou adicionar. Research não acessa nem abre URLs, não salva automaticamente e não é um gerador de referências ABNT. Reading é uma estimativa aproximada, não uma análise de compreensão ou resumo por IA. O armazenamento preserva registros anteriores de sessão compatíveis, normaliza referências e limita a quantidade de itens. As três permissões originais e a CSP permanecem inalteradas.

Testes novos: sanitização de URL, rejeição de esquemas e credenciais, limites de metadados, referências e normalização, filtro e cópia textual, estimativa de leitura, expansão de frases. A interface e as APIs de extensão ainda precisam de validação em Chrome, Edge e Opera.

## Novidades da a3 — Smart Automation

- Autofill: aceita somente inputs vazios com autocomplete exato de empresa, cargo, nome, e-mail ou website HTTPS. A extensão rejeita campos sensíveis por tipo, metadados conhecidos e formulários com indicadores de autenticação ou cartão, além de campos ocultos, desabilitados ou ambíguos. A prévia expira em 60 segundos e é vinculada à aba, documento e elemento. O valor informado fica na interface temporariamente, não é salvo no storage.session. A confirmação escreve apenas no campo escolhido, sem disparar eventos de formulário, focar, clicar ou enviar. Páginas podem observar ou transmitir valores por conta própria e podem rotular campos incorretamente. Use exclusivamente dados fictícios. Algumas páginas com frameworks controlados podem não reconhecer a escrita sem eventos. Não há garantia de detecção de todos os campos sensíveis.
- Expand: atalhos /obg, /rev, /ola e /att; até 20 regras personalizadas de sessão, 1.000 caracteres cada. Expansão somente de tokens separados por espaços, sem recursão, sem monitoramento de teclado ou escrita externa. Não guarde segredos nos atalhos.
- Mantidas as três permissões e a CSP. O teste do código injetado utiliza VM JavaScript e DOM simulado, não navegador real.
- Teste manual em uma página de teste HTTPS confiável com inputs explícitos, por exemplo `autocomplete="organization"`, `autocomplete="email"` e um input password separado. Confirme que a prévia não modifica o campo, a confirmação escreve somente no alvo, campos já preenchidos/ocultos/duplicados são recusados, navegação invalida a prévia, e que nenhum envio é iniciado pela extensão. Teste também alterações de valor entre prévia e confirmação, expiração, painel (Autofill indisponível), reabertura da sessão e limpeza de atalhos. Não use páginas reais de login, pagamento ou produção para esse teste.

## Novidades da a4 — Intelligent Text

- 63 regras ortográficas (PT-BR 27, EN 19, ES 17) e seis sugestões gramaticais simples (duas por idioma). Seleção explícita do idioma. Não é IA, tradução livre nem revisão contextual completa.
- Prévia não destrutiva com lista de alterações, opção de copiar, confirmação para aplicar somente no editor interno e desfazer da última aplicação. Alterar texto, idioma, dicionário ou opção gramatical invalida a prévia. Editar manualmente o texto encerra o histórico de desfazer.
- Até 100 palavras ignoradas, separadas por vírgulas, mantidas apenas no editor. Limite de 12.000 unidades UTF-16 de entrada e saída e 500 sugestões por revisão. Heurísticas preservam URLs, e-mails, caminhos, identificadores e código delimitado por crases; não identificam todo código ou conteúdo sensível.
- Seleção da página somente após clique no popup, pelas permissões existentes; nenhuma alteração em páginas, nenhuma transmissão de texto, nenhuma nova permissão ou processo residente. Fechar ou trocar de ferramenta descarta o rascunho.
- Testes Node: 32 aprovados, incluindo oito casos novos de revisão e transições do editor. A validação nativa de popup, captura, clipboard e armazenamento de sessão permanece pendente; o ambiente já bloqueou o Chromium por política administrativa. O roteiro de interface simulada foi ampliado, mas não foi executado nesta entrega.
- Teste manual: digite `Concerteza a gente fomos.`, revise, confira as duas sugestões, confirme, desfaça e verifique o texto original. Troque para inglês e teste `teh she have`; desligue gramática e confira que apenas a ortografia é sugerida. Altere o texto depois da prévia e confira que a aplicação é desabilitada. Use seleção apenas em página HTTP(S) de teste confiável.

## Novidades da a5 — Aeris Connect

- Três modos independentes: assistente, revisão contextual e resumo. Digite apenas o texto que deseja enviar, escolha o nome exato do modelo local instalado, marque a autorização, conceda a permissão opcional do navegador e clique em Enviar à IA local. Não há busca automática de modelos, leitura de páginas, histórico de conversas, execução de ferramentas, inicialização de Ollama ou requisições de fundo.
- Copiar texto para Desktop e Copiar resposta são ações explícitas. Cole manualmente no Aeris Desktop Text ou Companion. Não há native messaging, socket próprio, sincronização de registros ou modificação do Desktop publicado.
- O único destino programado é POST http://127.0.0.1:11434/api/chat, com redirecionamentos recusados, sem credenciais, sem cache e sem referenciador. O padrão de permissão Chromium não restringe portas; a CSP restringe a porta a 11434. A autorização de interface é temporária, mas a permissão de host pode persistir no navegador. Revogar acesso local remove essa permissão; também é possível removê-la nas configurações do navegador. Trocar ferramenta ou fechar a interface cancela a solicitação local e descarta o rascunho. Cancelar não garante que o servidor pare o processamento já iniciado.
- Limites: 4.000 unidades UTF-16 por mensagem/resposta, 256 KiB recebidos, 45 segundos, contexto solicitado de 4.096 tokens e até 512 tokens gerados; keep_alive=0. Respostas inválidas, chamadas de ferramenta e resultados obsoletos são recusados. A IA pode errar ou inventar fatos; o prompt não é uma barreira de segurança. Não confie em conteúdo de saída como comando.
- Requisito opcional: instalação e execução do Ollama com um modelo local compatível, suficiente memória e espaço. A conexão depende das políticas de origem e permissões do navegador e do servidor. Não exponha Ollama na rede, não libere origens indiscriminadamente e não altere proteções administrativas. Se a origem da extensão exigir configuração, consulte a documentação oficial do Ollama para permitir somente a origem exata da sua extensão. O loopback não garante que um servidor local, proxy ou modelo não encaminhe dados; use dados fictícios, não segredos. Nenhum modelo incluído no ZIP.
- Teste manual: sem Ollama, confirme que a interface abre normalmente e enviar está desabilitado. Marque consentimento, autorize a permissão, selecione modelo instalado e envie texto fictício. Confira resposta; modifique o texto ou cancele durante solicitação, e confirme que a resposta antiga não aparece. Revogue a permissão e confira que enviar fica bloqueado. Reabra a interface e confira nova autorização. Teste o botão de cópia colando em Text do Desktop. Se necessário use painel completo para que o popup não feche durante a confirmação.
- Validação desta entrega: 40 testes Node passaram, oito novos referentes ao protocolo, limites, manifesto e cancelamento. Transporte simulado, não servidor Ollama real. Validação nativa Chromium, permissões, clipboard e UI Connect continuam pendentes; o bloqueio administrativo anterior permanece uma limitação. Nenhuma publicação externa.


## Novidades da a6 — Security & Eco Engine

- Privacy: painel com contagens de registros de sessão e consulta/revogação explícita da permissão opcional de loopback. Não lê conteúdo de páginas ou histórico. Total: 16 ferramentas.
- Limpar sessão grava um identificador de limpeza novo e estado vazio, dentro do mesmo bloqueio usado pelas operações de escrita. As telas abertas que recebem o evento de armazenamento descartam rascunhos, prévias e respostas; operações enfileiradas com identificador antigo são recusadas. Não é apagamento seguro, não limpa clipboard, dados das páginas, requisições já recebidas pelo Ollama ou permissões do navegador. Revogue a permissão separadamente.
- Normalização dos registros de tarefas e snippets com limites de leitura (100 candidatos por lista), 30 itens aceitos, identificadores únicos, texto não vazio e sem NUL. Campos desconhecidos descartados.
- Eco Engine: Focus usa um timeout único somente quando há prazo ativo e a interface está visível; recalcula ao voltar à tela e ao receber alteração de sessão. Nenhum intervalo permanente, sem alarme de fundo. Não foram medidos CPU/RAM reais.
- CSP com default-src none, scripts/estilos/imagens próprios, frames e formulários bloqueados e conexão restrita ao endpoint de loopback pela política de porta/origem. Nenhuma nova permissão. Cancelamento antes do envio não chama o transporte.
- Acessibilidade: foco de teclado mais evidente, compatibilidade CSS com cores forçadas e rótulos com maior contraste. Não constitui certificação de acessibilidade.
- Validação: 47 testes Node passaram, incluindo sete novos casos de normalização, limpeza, agendamento, cancelamento e política de conteúdo. Sintaxe JS verificada. A validação nativa Chromium/Opera/Edge, eventos reais entre telas, permissão opcional, Ollama e acessibilidade continuam pendentes.
- Teste manual: abra popup e painel, crie tarefa e rascunho em telas distintas, limpe a sessão e confirme descarte em ambas. Abra Privacy, consulte e revogue acesso local, verifique bloqueio de envio. Inicie Focus e alterne entre abas, confirme que o prazo é recalculado ao voltar. Teste navegação com Tab e modo de alto contraste. Utilize dados fictícios.
