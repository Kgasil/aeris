from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib, os, shutil, re
from playwright.sync_api import sync_playwright, expect

root=Path(__file__).resolve().parents[1]/'extension'
extid=''.join(chr(97+int(c,16)) for c in hashlib.sha256(str(root).encode()).hexdigest()[:32])
with TemporaryDirectory() as tmp, sync_playwright() as p:
    ctx=p.chromium.launch_persistent_context(tmp,executable_path=os.environ.get('CHROMIUM_PATH',shutil.which('chromium')),headless=True,timeout=8000,ignore_default_args=["--disable-extensions"],args=['--no-sandbox',f'--disable-extensions-except={root}',f'--load-extension={root}'])
    page=ctx.new_page(); errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_default_timeout(5000); expect.set_options(timeout=5000)
    url=f'chrome-extension://{extid}/index.html'
    page.goto(url); expect(page.get_by_role('heading',name='Text',exact=True)).to_be_visible()
    def tool(t):page.get_by_role('button',name=t,exact=True).click()
    def outcome(t):expect(page.locator('.result')).to_contain_text(t)
    page.get_by_label('Texto',exact=True).fill('Concerteza');page.get_by_role('button',name='Revisar').click();outcome('Com certeza')
    tool('Calculator');page.get_by_label('A / custo').fill('60');page.get_by_label('B / preço').fill('100');page.get_by_label('Operação').select_option('margin');page.get_by_role('button',name='Calcular').click();outcome('40')
    tool('Convert');page.get_by_label('Valor').fill('1000');page.get_by_role('button',name='Converter').click();outcome('1 km')
    tool('Link');page.get_by_label('URL completa').fill('http://example.com');page.get_by_role('button',name='Analisar').click();outcome('Sem HTTPS')
    tool('Translate');page.get_by_label('Frase').fill('bom dia');page.get_by_role('button',name='Consultar').click();outcome('good morning')
    tool('Checklist');page.get_by_label('Nova tarefa').fill('<script>teste</script>');page.get_by_role('button',name='Adicionar').click();expect(page.get_by_text('<script>teste</script>',exact=True)).to_be_visible();page.get_by_role('checkbox').check();expect(page.locator('.done')).to_have_text('<script>teste</script>')
    tool('Snippets');page.get_by_label('Novo texto').fill('Resposta de teste');page.get_by_role('button',name='Adicionar').click();expect(page.get_by_text('Resposta de teste',exact=True)).to_be_visible()
    tool('Focus');page.get_by_label('Minutos').fill('1');page.get_by_role('button',name='Iniciar').click();expect(page.locator('.clock')).to_have_text(re.compile(r'^(01:00|00:5[0-9])$'))
    with ctx.expect_page() as opened:page.get_by_role('button',name='↗ Painel').click()
    full=opened.value;expect(full.get_by_role('heading',name='Text')).to_be_visible();full.get_by_role('button',name='Checklist',exact=True).click();expect(full.get_by_role('checkbox')).to_be_checked();full.get_by_role('button',name='Capture',exact=True).click();expect(full.get_by_role('button',name='Capturar seleção')).to_be_disabled()
    tool('Research');page.get_by_label('Título').fill('Referência');page.get_by_label('URL HTTP(S)').fill('https://example.test/path?token=secret');page.get_by_label('Nota').fill('Ciência');page.get_by_role('button',name='Adicionar referência').click();expect(page.locator('.ref-card')).to_contain_text('https://example.test');assert 'token=' not in page.locator('.ref-card').inner_text();page.get_by_label('Filtrar referências').fill('ciencia');expect(page.locator('.ref-card')).to_have_count(1)
    tool('Reading');page.get_by_label('Texto para leitura').fill('um dois');page.get_by_role('button',name='Analisar leitura').click();outcome('2 palavras')
    tool('Expand');page.get_by_label('Texto com atalhos').fill('/obg');page.get_by_role('button',name='Expandir',exact=True).click();expect(page.locator('.result').first).to_contain_text('Obrigado pelo retorno.')
    tool('Privacy');outcome('Tarefas: 1');page.get_by_role('button',name='Consultar acesso local').click();expect(page.get_by_text('Acesso local: não concedido',exact=True)).to_be_visible()
    tool('Connect');expect(page.get_by_role('button',name='Enviar à IA local')).to_be_disabled()
    page.reload();tool('Focus');expect(page.locator('.clock')).not_to_have_text('00:00');page.get_by_role('button',name='Parar').click();expect(page.locator('.clock')).to_have_text('00:00')
    page.on('dialog',lambda d:d.accept());page.get_by_role('button',name='Limpar sessão').click();expect(page.get_by_role('status')).to_have_text('Sessão limpa.');tool('Checklist');expect(page.get_by_role('checkbox')).to_have_count(0);tool('Snippets');expect(page.locator('.entry')).to_have_count(0)
    assert not errors,errors
    print('PASS: Chromium MV3 load, 13 tool flows, workspace, session persistence, clear and Capture workspace restriction')
    ctx.close()
