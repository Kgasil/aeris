from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib, os, shutil
from playwright.sync_api import sync_playwright, expect

root=Path(__file__).resolve().parents[1]/'extension'
extid=''.join(chr(97+int(c,16)) for c in hashlib.sha256(str(root).encode()).hexdigest()[:32])
with TemporaryDirectory() as tmp, sync_playwright() as p:
    ctx=p.chromium.launch_persistent_context(tmp,executable_path=os.environ.get('CHROMIUM_PATH',shutil.which('chromium')),headless=True,timeout=8000,ignore_default_args=["--disable-extensions"],args=['--no-sandbox'])
    page=ctx.new_page(); errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_default_timeout(5000); expect.set_options(timeout=5000)
    url='http://localhost:8765/index.html'
    ctx.add_init_script("""(() => { const key='aeris-mock-session'; const listeners=[]; const load=()=>JSON.parse(localStorage.getItem(key)||'{}'); const notify=(old,next)=>{const changes={};for(const k of new Set([...Object.keys(old),...Object.keys(next)]))changes[k]={oldValue:old[k],newValue:next[k]};for(const l of listeners)l(changes,'session');}; window.addEventListener('storage',e=>{if(e.key===key)notify(JSON.parse(e.oldValue||'{}'),JSON.parse(e.newValue||'{}'));}); window.chrome={storage:{session:{get:async k=>({[k]:load()[k]}),set:async o=>{const old=load(),next={...old,...o};localStorage.setItem(key,JSON.stringify(next));notify(old,next);},remove:async k=>{const old=load(),next={...old};delete next[k];localStorage.setItem(key,JSON.stringify(next));notify(old,next);}},onChanged:{addListener:l=>listeners.push(l)}},runtime:{getURL:x=>location.origin+'/'+x},tabs:{create:async({url})=>window.open(url,'_blank'),query:async()=>[{id:1,url:'https://example.test/a?secret=1#fragment',title:'Página de teste'}]},scripting:{executeScript:async()=>[{result:'Texto de teste'}]}}; })();""")
    def route(r):
        name=r.request.url.split('?',1)[0].rsplit('/',1)[-1]
        f=root/name
        if name=='symbol.svg':f=root/'icons'/'symbol.svg'
        if f.is_file():r.fulfill(path=str(f))
        else:r.fulfill(status=404,body='Not found')
    ctx.route('http://localhost:8765/**',route)
    page.goto(url); expect(page.get_by_role('heading',name='Text',exact=True)).to_be_visible()
    def tool(t):page.get_by_role('button',name=t,exact=True).click()
    def outcome(t):expect(page.locator('.result')).to_contain_text(t)
    page.get_by_label('Texto',exact=True).fill('Concerteza');page.get_by_role('button',name='Revisar').click();outcome('Com certeza')
    expect(page.get_by_label('Texto',exact=True)).to_have_value('Concerteza');page.get_by_role('button',name='Aplicar sugestões').click();expect(page.get_by_label('Texto',exact=True)).to_have_value('Com certeza');page.get_by_role('button',name='Desfazer').click();expect(page.get_by_label('Texto',exact=True)).to_have_value('Concerteza')
    page.get_by_label('Idioma').select_option('en');page.get_by_label('Texto',exact=True).fill('teh she have');page.get_by_role('button',name='Revisar').click();outcome('the she has');page.get_by_label('Texto',exact=True).fill('new text');expect(page.get_by_role('button',name='Aplicar sugestões')).to_be_disabled()
    tool('Calculator');page.get_by_label('A / custo').fill('60');page.get_by_label('B / preço').fill('100');page.get_by_label('Operação').select_option('margin');page.get_by_role('button',name='Calcular').click();outcome('40')
    tool('Convert');page.get_by_label('Valor').fill('1000');page.get_by_role('button',name='Converter').click();outcome('1 km')
    tool('Link');page.get_by_label('URL completa').fill('http://example.com');page.get_by_role('button',name='Analisar').click();outcome('Sem HTTPS')
    tool('Translate');page.get_by_label('Frase').fill('bom dia');page.get_by_role('button',name='Consultar').click();outcome('good morning')
    tool('Checklist');page.get_by_label('Nova tarefa').fill('<script>teste</script>');page.get_by_role('button',name='Adicionar').click();expect(page.get_by_text('<script>teste</script>',exact=True)).to_be_visible();page.get_by_role('checkbox').check();expect(page.locator('.done')).to_have_text('<script>teste</script>')
    tool('Snippets');page.get_by_label('Novo texto').fill('Resposta de teste');page.get_by_role('button',name='Adicionar').click();expect(page.get_by_text('Resposta de teste',exact=True)).to_be_visible()
    tool('Focus');page.get_by_label('Minutos').fill('1');page.get_by_role('button',name='Iniciar').click();expect(page.locator('.clock')).to_have_text('01:00')
    with ctx.expect_page() as opened:page.get_by_role('button',name='↗ Painel').click()
    full=opened.value;expect(full.get_by_role('heading',name='Text')).to_be_visible();full.get_by_role('button',name='Checklist',exact=True).click();expect(full.get_by_role('checkbox')).to_be_checked();full.get_by_role('button',name='Capture',exact=True).click();expect(full.get_by_role('button',name='Capturar seleção')).to_be_disabled()
    tool('Capture');page.get_by_role('button',name='Capturar seleção').click();outcome('Texto de teste')
    tool('Page');page.get_by_role('button',name='Consultar página').click();outcome('https://example.test');assert '?secret=' not in page.locator('.result').inner_text()
    tool('Research');page.get_by_role('button',name='Preencher da página').click();expect(page.get_by_label('Título')).to_have_value('Página de teste');page.get_by_label('Nota').fill('Pesquisa científica');page.get_by_role('button',name='Adicionar referência').click();expect(page.locator('.ref-card')).to_have_count(1);page.get_by_label('Filtrar referências').fill('cientifica');expect(page.locator('.ref-card')).to_have_count(1);page.get_by_label('Filtrar referências').fill('ausente');expect(page.locator('.ref-card')).to_have_count(0)
    tool('Reading');page.get_by_role('button',name='Usar seleção').click();expect(page.get_by_label('Texto para leitura')).to_have_value('Texto de teste');page.get_by_role('button',name='Analisar leitura').click();outcome('3 palavras')
    page.reload();tool('Focus');expect(page.locator('.clock')).not_to_have_text('00:00');page.get_by_role('button',name='Parar').click();expect(page.locator('.clock')).to_have_text('00:00')
    page.on('dialog',lambda d:d.accept());page.get_by_role('button',name='Limpar sessão').click();expect(page.get_by_role('status')).to_have_text('Sessão limpa.');tool('Checklist');expect(page.get_by_role('checkbox')).to_have_count(0);tool('Snippets');expect(page.locator('.entry')).to_have_count(0)
    assert not errors,errors
    print('PASS: Chromium UI with mocked extension APIs, 12 tool flows, workspace, session persistence, clear and Capture workspace restriction')
    ctx.close()
