"""Deterministic unpacked-extension ZIP with a strict runtime file allowlist."""
from pathlib import Path
import hashlib, json, re, zipfile
ROOT=Path(__file__).resolve().parent
FILES={'manifest.json','index.html','style.css','app.js','core.js','context.js','automation.js','intelligent-text.js','connect.js','session.js','icons/symbol.svg','icons/16.png','icons/32.png','icons/48.png','icons/128.png'}
def build(out):
    src=ROOT/'extension'
    actual={p.relative_to(src).as_posix() for p in src.rglob('*') if p.is_file()}
    if actual!=FILES or any(p.is_symlink() for p in src.rglob('*')): raise ValueError('Unexpected runtime files')
    m=json.loads((src/'manifest.json').read_text())
    assert m['manifest_version']==3 and m['version']=='1.0.0'
    assert m['permissions']==['activeTab','scripting','storage'] and m['optional_host_permissions']==['http://127.0.0.1/*']
    assert not any(k in m for k in ('background','content_scripts','host_permissions','externally_connectable','web_accessible_resources','update_url'))
    assert m['action']['default_popup']=='index.html'
    assert set(m['icons'].values())<=FILES and set(m['action']['default_icon'].values())<=FILES
    html=(src/'index.html').read_text()
    assert '1.0.0' in html and not re.search(r'(?:src|href)\s*=\s*[\"\'](?:https?:|//)',html,re.I)
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in sorted(FILES):
            info=zipfile.ZipInfo(name,(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            z.writestr(info,(src/name).read_bytes(),compresslevel=9)
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None and set(z.namelist())==FILES
        assert all(z.read(n)==(src/n).read_bytes() for n in FILES)
    return hashlib.sha256(out.read_bytes()).hexdigest()
if __name__=='__main__':
    import sys
    out=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'Aeris-Extension-v1.0.0-install.zip'
    print(build(out),out.name)
