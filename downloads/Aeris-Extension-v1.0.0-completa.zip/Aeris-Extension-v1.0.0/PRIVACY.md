# Aeris Extension — Aviso de privacidade / Privacy notice

**1.0.0 · K&G Vision · distribuição manual**

Não há conta obrigatória, publicidade, telemetria implementada, servidor próprio ou transmissão automática de páginas. A extensão não tem acesso permanente a todos os sites. Usa activeTab e scripting somente após ação explícita para consultar a aba ou seleção e preencher um campo permitido após prévia; storage.session mantém tarefas, snippets, referências, atalhos e prazo do Focus. Dados de sessão não são criptografados. Não use dados confidenciais; páginas podem observar valores inseridos. O sistema de cópia interage com a área de transferência apenas a pedido do usuário.

Connect é opcional e solicita permissão de host para 127.0.0.1; a política CSP e o código limitam a conexão programada a http://127.0.0.1:11434/api/chat. O texto digitado é enviado somente após autorização e clique. O servidor/modelo local pode encaminhar ou registrar dados; Aeris não controla seu comportamento. Nenhuma chamada de ferramenta ou execução de comandos. Cancelar não garante interrupção do servidor. Sem histórico automático de IA. A permissão opcional pode persistir no navegador; use Privacy para revogá-la.

Limpar sessão descarta registros e rascunhos internos das telas que recebem o evento; não limpa a área de transferência, dados das páginas, dados já entregues ao servidor ou permissões do navegador. Remover a extensão é possível no gerenciador de extensões. Sem garantia de apagamento seguro. As políticas do navegador e do dispositivo também se aplicam.

O código é disponibilizado para avaliação; licença de redistribuição deve ser definida pelo titular. Este documento descreve o comportamento implementado, não uma certificação nem uma declaração de conformidade legal auditada. Relate problemas pelo repositório https://github.com/Kgasil/aeris/issues sem incluir segredos, dados pessoais ou conteúdo de páginas.

**English:** Local-first experimental extension with no implemented telemetry or background monitoring. Explicit active-tab actions only, nonencrypted session records, manual clipboard transfer, optional loopback AI. The local AI server is outside Aeris control and may retain or forward submitted text. Clear session and revoke access separately. Use dummy data only. No store approval or audited compliance is claimed.
