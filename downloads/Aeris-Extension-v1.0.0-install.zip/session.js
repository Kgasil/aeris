import {normalizeReferences} from './context.js';
import {normalizeRules} from './automation.js';
const idValid=v=>typeof v==='string'&&/^[a-zA-Z0-9-]{1,80}$/.test(v);
function entries(list,limit){const out=[],seen=new Set();if(!Array.isArray(list))return out;for(const x of list.slice(0,100)){if(!x||!idValid(x.id)||seen.has(x.id)||typeof x.text!=='string'||!x.text.trim()||x.text.length>limit||x.text.includes('\0'))continue;seen.add(x.id);out.push({id:x.id,text:x.text,done:x.done===true});if(out.length===30)break;}return out;}
export function normalize(s,now=Date.now()){const v={snippets:[],tasks:[],references:[],rules:[],end:0,reset:''};if(!s||typeof s!=='object')return v;v.snippets=entries(s.snippets,1000);v.tasks=entries(s.tasks,200);v.references=normalizeReferences(s.references);v.rules=normalizeRules(s.rules);if(Number.isFinite(s.end)&&s.end>now&&s.end<=now+120*60000)v.end=s.end;if(idValid(s.reset))v.reset=s.reset;return v;}
export function cleared(reset){if(!idValid(reset))throw Error('Identificador de sessão inválido.');return {...normalize(null),reset};}
export function assertCurrent(current,expected){if(current.reset!==expected)throw Error('Sessão limpa em outra tela. Repita a operação.');}
export function focusDelay(end,now,visible){return visible&&Number.isFinite(end)&&end>now?Math.min(1000,end-now):null;}
export function summary(s,now=Date.now()){return {snippets:s.snippets.length,tasks:s.tasks.length,references:s.references.length,rules:s.rules.length,focus:s.end>now};}
