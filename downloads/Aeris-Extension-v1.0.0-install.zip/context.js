import {checked,item,textStats} from './core.js';
// Only HTTP(S), and only origin by default. Never keep credentials, queries or fragments.
export function cleanPage(raw,includePath=false){
  checked(raw,2048); let u; try{u=new URL(raw.trim());}catch{throw Error('URL inválida.');}
  if(!['http:','https:'].includes(u.protocol)||u.username||u.password)throw Error('URL HTTP(S) sem credenciais necessária.');
  return includePath&&u.pathname!=='/'?u.origin+u.pathname:u.origin;
}
export function pageInfo(tab,includePath=false){
  if(!tab||!Number.isInteger(tab.id)||tab.id<0)throw Error('Página indisponível.');
  const url=cleanPage(tab.url||'',includePath);
  const title=typeof tab.title==='string'?tab.title.slice(0,200).trim():'';
  return {title,url};
}
export function reference(title,raw,note,includePath=false){
  const url=cleanPage(raw,includePath);return {title:item(title,200),url,note:checked(note,2000).trim()};
}
export function normalizeReferences(values){
  if(!Array.isArray(values))return [];
  const out=[],ids=new Set();for(const x of values.slice(0,100)){
    if(!x||typeof x.id!=='string'||!/^[a-zA-Z0-9-]{1,80}$/.test(x.id)||ids.has(x.id))continue;
    try{const v=reference(x.title,x.url,x.note,true);ids.add(x.id);out.push({id:x.id,...v});}catch{}
    if(out.length===30)break;
  }return out;
}
export function searchReferences(values,query){const q=checked(query,200).normalize('NFD').replace(/\p{M}/gu,'').toLowerCase().trim();return values.filter(x=>[x.title,x.url,x.note].some(s=>s.normalize('NFD').replace(/\p{M}/gu,'').toLowerCase().includes(q)));}
export function reading(s){const stats=textStats(s);const paragraphs=s.trim()?s.trim().split(/\r?\n\s*\r?\n/u).filter(x=>x.trim()).length:0;return {...stats,paragraphs,seconds:Math.ceil(stats.words/200*60)};}
export function citation(r){const v=reference(r.title,r.url,r.note,true);return `${v.title}\n${v.url}${v.note?'\nNota: '+v.note:''}`;}
