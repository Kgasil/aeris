import {checked,item} from './core.js';
export const fields=Object.freeze({organization:'Empresa','organization-title':'Cargo',name:'Nome',email:'E-mail',url:'Website'});
export function fillValue(kind,raw){
  if(!Object.hasOwn(fields,kind))throw Error('Campo não permitido.');
  const value=item(raw,200);
  if(/[\x00-\x1f\x7f]/u.test(raw))throw Error('Use texto de uma linha.');
  if(kind==='email'&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/u.test(value))throw Error('E-mail inválido.');
  if(kind==='url'){let u;try{u=new URL(value);}catch{throw Error('Website inválido.');}if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash)throw Error('Website HTTPS sem credenciais, parâmetros ou fragmentos.');}
  return value;
}
export const templates=Object.freeze({'/obg':'Obrigado pelo retorno.','/rev':'Vou revisar as informações e retorno em breve.','/ola':'Olá! Espero que esteja bem.','/att':'Atenciosamente,'});
export function rule(alias,text){if(typeof alias!=='string'||!/^\/[a-z][a-z0-9_-]{0,19}$/.test(alias))throw Error('Use / seguido de 1 a 20 letras minúsculas, números, hífen ou _.');return {alias,text:item(text,1000)};}
export function normalizeRules(raw){const out=[],seen=new Set(Object.keys(templates));if(!Array.isArray(raw))return out;for(const x of raw.slice(0,100)){try{const v=rule(x.alias,x.text);if(seen.has(v.alias))continue;seen.add(v.alias);out.push(v);}catch{}if(out.length===20)break;}return out;}
export function expand(text,rules=[]){checked(text);const map=new Map([...Object.entries(templates),...normalizeRules(rules).map(x=>[x.alias,x.text])]);return checked(text.replace(/(^|\s)(\/[a-z][a-z0-9_-]{0,19})(?=\s|$)/g,(m,space,alias)=>space+(map.get(alias)??alias)));}
// Executed only after direct user action in the top frame's isolated world.
// Self-contained: Chrome serializes this function, not its module closure.
export function pageFill(action,kind,nonce,value=''){
  const key='__aerisFillPreviewV1';
  const fail=message=>({ok:false,message});
  const allowed=['organization','organization-title','name','email','url'];
  if(location.protocol!=='https:'||!allowed.includes(kind)||!/^[-a-f0-9]{36}$/.test(nonce))return fail('Página HTTPS e campo permitido necessários.');
  const eligible=e=>{
    if(!(e instanceof HTMLInputElement)||!e.isConnected||e.ownerDocument!==document||e.disabled||e.matches(':disabled')||e.readOnly||e.value!==''||e.closest('[inert],[hidden],[aria-hidden="true"]'))return false;
    if(e.form?.querySelector('input[type="password"],input[autocomplete*="password" i],input[autocomplete*="one-time-code" i],input[autocomplete*="cc-" i]'))return false;
    if(e.getAttribute('autocomplete')?.trim().toLowerCase()!==kind)return false;
    if(!({email:['email','text'],url:['url','text'],organization:['text'],'organization-title':['text'],name:['text']}[kind]).includes(e.type))return false;
    // Conservative rejection of known credential/payment/identity indicators.
    const label=[e.name,e.id,e.placeholder,e.getAttribute('aria-label'),...Array.from(e.labels||[],l=>l.textContent)].join(' ').normalize('NFD').replace(/\p{M}/gu,'').toLowerCase();
    if(/pass(word)?|senha|secret|token|otp|pin\b|cvv|cvc|card|cartao|credit|debito|bank|banco|conta|cpf|cnpj|ssn|passport|passaporte|documento|rg\b|login|user.?name|usuario|auth|verification|verificacao|security|seguranca/.test(label))return false;
    const rect=e.getBoundingClientRect(),style=getComputedStyle(e);
    return rect.width>0&&rect.height>0&&style.visibility==='visible'&&style.display!=='none'&&style.opacity!=='0'&&(!e.checkVisibility||e.checkVisibility({checkOpacity:true,checkVisibilityCSS:true}));
  };
  const candidates=()=>{const list=document.querySelectorAll('input[autocomplete]');return list.length>500?null:Array.from(list).filter(eligible);};
  if(action==='preview'){
    delete globalThis[key];
    const matches=candidates();if(!matches)return fail('Formulário muito grande.');if(matches.length!==1)return fail('É necessário exatamente um campo vazio, visível e compatível.');
    globalThis[key]={nonce,kind,element:matches[0],href:location.href,until:Date.now()+60000};
    return {ok:true,origin:location.origin};
  }
  if(action!=='apply')return fail('Ação inválida.');
  const preview=globalThis[key];delete globalThis[key];
  if(!preview||preview.nonce!==nonce||preview.kind!==kind||preview.href!==location.href||Date.now()>preview.until||!eligible(preview.element))return fail('Prévia expirada ou campo alterado. Prepare novamente.');
  const matches=candidates();
  if(!matches||matches.length!==1||matches[0]!==preview.element)return fail('Formulário alterado ou ambíguo. Prepare novamente.');
  const e=preview.element;
  if(typeof value!=='string'||!value.trim()||value.length>200||/[\x00-\x1f\x7f]/u.test(value)||(e.maxLength>=0&&value.length>e.maxLength))return fail('Valor incompatível com o campo.');
  // Only a single explicit write. No click, input/change dispatch, focus, or submit.
  Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(e,value);
  return e.value===value?{ok:true}:{ok:false,message:'O campo não aceitou o valor.'};
}
