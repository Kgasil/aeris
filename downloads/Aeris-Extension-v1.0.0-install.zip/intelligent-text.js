// Deterministic, offline suggestions; no model or external page writes.
export const TEXT_LIMIT=12000;
const WORDS={"pt":{"voce":"você","voces":"vocês","nao":"não","tambem":"também","informacao":"informação","informacoes":"informações","reuniao":"reunião","concerteza":"com certeza","derrepente":"de repente","excessão":"exceção","previlégio":"privilégio","nescessário":"necessário","seje":"seja","esteje":"esteja","portugês":"português","obrigatorio":"obrigatório","ola":"olá","adiministrar":"administrar","beneficiente":"beneficente","paralização":"paralisação","impecilho":"empecilho","reinvindicar":"reivindicar","indentidade":"identidade","progeto":"projeto","pesquiza":"pesquisa","muinto":"muito","necessario":"necessário"},"en":{"teh":"the","recieve":"receive","recieved":"received","seperate":"separate","definately":"definitely","adress":"address","occured":"occurred","wich":"which","enviroment":"environment","goverment":"government","becuase":"because","accomodate":"accommodate","tommorow":"tomorrow","sucessful":"successful","begining":"beginning","neccessary":"necessary","existance":"existence","recomendation":"recommendation","untill":"until"},"es":{"tambien":"también","informacion":"información","reunion":"reunión","comunicacion":"comunicación","organizacion":"organización","nesesario":"necesario","desarollo":"desarrollo","exepción":"excepción","aser":"hacer","nececario":"necesario","desición":"decisión","exelente":"excelente","conosimiento":"conocimiento","investigacion":"investigación","educacion":"educación","tambiem":"también","proyeto":"proyecto"}};
const PHRASES={"pt":{"a gente fomos":"a gente foi","a gente estamos":"a gente está"},"en":{"he have":"he has","she have":"she has"},"es":{"yo tiene":"yo tengo","nosotros tiene":"nosotros tenemos"}};
export const languages=Object.freeze([['pt','Português (BR)'],['en','English'],['es','Español']].map(Object.freeze));
export const ruleCounts=Object.freeze(Object.fromEntries(languages.map(([id])=>[id,Object.freeze({spelling:Object.keys(WORDS[id]).length,grammar:Object.keys(PHRASES[id]).length})])));
function text(s){if(typeof s!=='string'||s.length>TEXT_LIMIT)throw Error('Texto acima do limite de 12 mil caracteres.');return s;}
function lang(id){if(!Object.hasOwn(WORDS,id))throw Error('Idioma inválido.');return id;}
export function dictionary(raw){if(typeof raw!=='string'||raw.length>5000)throw Error('Dicionário inválido.');const terms=raw.split(',').map(x=>x.trim()).filter(Boolean);if(terms.length>100||terms.some(x=>x.length>50||!/^\p{L}[\p{L}\p{M}]*$/u.test(x)))throw Error('Use até 100 palavras de até 50 letras, separadas por vírgula.');return new Set(terms.map(x=>x.normalize('NFC').toLowerCase()));}
// Protect common URL/email/path/identifier patterns and backtick code. These
// heuristics are conservative, not a complete parser or secret detector.
const protectedPattern=/```[\s\S]*?(?:```|$)|`[^`\r\n]*(?:`|\r?\n|$)|(?:[a-z][a-z0-9+.-]*:\/\/|www\.)\S+|(?<![^\s<>@])[^\s<>@]+@[^\s<>@]+|(?:[a-z]:[\\/]|(?:^|(?<=[\s(]))\/|\.\.?[\\/]|\\\\)\S+|(?<![\p{L}\p{M}\p{N}_])[\p{L}\p{M}\p{N}_]+(?:[._/\\-][\p{L}\p{M}\p{N}_]+)+/giu;
const escape=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
function caseLike(before,after){if(before===before.toUpperCase())return after.toUpperCase();if(before===before.toLowerCase())return after;if(before[0]===before[0].toUpperCase()&&before.slice(1)===before.slice(1).toLowerCase())return after[0].toUpperCase()+after.slice(1);return before;}
export function reviewText(source,language='pt',{grammar=true,ignored=''}={}){
  text(source);lang(language);const skip=dictionary(ignored),rules=new Map(Object.entries(WORDS[language]).map(([k,v])=>[k,[v,'Ortografia']]));
  if(grammar)for(const [k,v] of Object.entries(PHRASES[language]))rules.set(k,[v,'Gramática (sugestão)']);
  const pattern=new RegExp('(?<![\\p{L}\\p{M}\\p{N}_])(?:'+[...rules.keys()].sort((a,b)=>b.length-a.length).map(escape).join('|')+')(?![\\p{L}\\p{M}\\p{N}_])','giu');
  const protectedRanges=[...source.matchAll(protectedPattern)].map(m=>[m.index,m.index+m[0].length]);let block=0,pos=0,parts=[],edits=[];
  for(const m of source.matchAll(pattern)){const start=m.index,end=start+m[0].length;while(block<protectedRanges.length&&protectedRanges[block][1]<=start)block++;if(block<protectedRanges.length&&protectedRanges[block][0]<end)continue;const before=m[0];if(before.split(' ').some(w=>skip.has(w.normalize('NFC').toLowerCase())))continue;const rule=rules.get(before.toLowerCase());if(!rule)continue;const after=caseLike(before,rule[0]);if(after===before)continue;if(edits.length>=500)throw Error('Muitas sugestões. Revise um trecho menor.');edits.push(Object.freeze({start,end,before,after,kind:rule[1]}));parts.push(source.slice(pos,start),after);pos=end;}
  parts.push(source.slice(pos));return Object.freeze({text:text(parts.join('')),edits:Object.freeze(edits)});
}
// One preview and one undo per editor instance; exact-source checks prevent stale
// application or overwriting a manually edited document. No persistence.
export function createReviewEditor(){let pending=null,undo=null;return Object.freeze({
  preview(source,language,options={}){pending=null;const grammar=options.grammar??true,ignored=options.ignored??'';const result=reviewText(source,language,{grammar,ignored});pending={source,language,grammar,ignored,result};return result;},
  invalidate(){pending=null;},
  apply(source,language,options={}){const p=pending;pending=null;if(!p||source!==p.source||language!==p.language||(options.grammar??true)!==p.grammar||(options.ignored??'')!==p.ignored||!p.result.edits.length)throw Error('Prévia ausente ou alterada. Revise novamente.');undo={before:source,after:p.result.text};return p.result.text;},
  canUndo(source){return !!undo&&undo.after===source;},
  undo(source){const u=undo;undo=null;pending=null;if(!u||source!==u.after)throw Error('Texto alterado; não é possível desfazer.');return u.before;},
  reset(){pending=null;undo=null;}
});}
