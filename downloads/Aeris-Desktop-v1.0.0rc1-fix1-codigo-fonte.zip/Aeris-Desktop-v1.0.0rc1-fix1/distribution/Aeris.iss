; Inno Setup 6.3+ / Windows 10 and 11 x64. Preview, not code-signed.
#ifndef AppVersion
  #error AppVersion must be supplied by build.ps1
#endif
#ifndef BundleDir
  #error BundleDir must be supplied by build.ps1
#endif
[Setup]
AppId={{76A8CB97-8F34-42A2-9B8D-462CAB196D85}
AppName=Project Aeris
AppVersion={#AppVersion}
AppPublisher=K&G Vision
AppPublisherURL=https://kgasil.github.io/aeris/
DefaultDirName={localappdata}\Programs\KGVision\Aeris
DefaultGroupName=Project Aeris
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64os
ArchitecturesInstallIn64BitMode=x64os
MinVersion=10.0
AppMutex=Local\KGVision.Aeris.Desktop
CloseApplications=no
RestartApplications=no
UninstallDisplayIcon={app}\Aeris.exe
SetupIconFile=aeris.ico
OutputBaseFilename=Aeris-{#AppVersion}-Windows-x64-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
InfoBeforeFile=PREVIEW.txt
[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"
[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; Flags: unchecked
[Files]
Source: "{#BundleDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Icons]
Name: "{autoprograms}\Project Aeris"; Filename: "{app}\Aeris.exe"; WorkingDir: "{app}"
Name: "{autodesktop}\Project Aeris"; Filename: "{app}\Aeris.exe"; WorkingDir: "{app}"; Tasks: desktopicon
; No automatic launch, autorun, updater, registry associations or deletion of user data.
