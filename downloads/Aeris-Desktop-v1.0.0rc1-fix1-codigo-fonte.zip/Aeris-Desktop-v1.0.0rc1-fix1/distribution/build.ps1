# Run on Windows x64, with CPython 3.12 x64 and Inno Setup 6.3+ installed.
[CmdletBinding()]
param([string]$Iscc = '', [switch]$PortableOnly)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ($env:OS -ne 'Windows_NT' -or $env:PROCESSOR_ARCHITECTURE -ne 'AMD64') { throw 'Windows x64 required.' }
$root = Split-Path -Parent $PSScriptRoot
$desktop = Join-Path $root 'desktop'
$out = Join-Path $PSScriptRoot 'out'
# Unique staging path: no recursive deletion of a user-selected directory.
$stage = Join-Path $out ([guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stage -Force | Out-Null
function Invoke-Checked([string]$File, [string[]]$Arguments) {
    & $File @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Failed: $File (exit $LASTEXITCODE)" }
}
Invoke-Checked 'py' @('-3.12-64','-c','import sys, tkinter; assert sys.version_info[:2] == (3,12) and sys.maxsize > 2**32')
$venv = Join-Path $stage 'venv'
Invoke-Checked 'py' @('-3.12-64','-m','venv',$venv)
$python = Join-Path $venv 'Scripts\python.exe'
Invoke-Checked $python @('-m','pip','--disable-pip-version-check','install','-r',(Join-Path $PSScriptRoot 'requirements-build.txt'))
Push-Location $desktop
try {
    Invoke-Checked $python @('-m','unittest','discover','-q')
    $version = & $python -c 'from aeris import __version__; print(__version__)'
    if ($LASTEXITCODE -ne 0 -or $version -notmatch '^\d+\.\d+\.\d+(a|rc)\d+$') { throw 'Invalid build version' }
    $dist = Join-Path $stage 'dist'
    Invoke-Checked $python @('-m','PyInstaller','--noconfirm','--clean','--onedir','--windowed','--noupx','--name','Aeris','--icon',(Join-Path $PSScriptRoot 'aeris.ico'),'--add-data','aeris/catalog.json:aeris','--exclude-module','argostranslate','--distpath',$dist,'--workpath',(Join-Path $stage 'work'),'--specpath',$stage,'main.py')
    $bundle = Join-Path $dist 'Aeris'
    $exe = Join-Path $bundle 'Aeris.exe'
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Missing executable' }
    $process = Start-Process -FilePath $exe -ArgumentList '--self-test-full' -PassThru
    if (-not $process.WaitForExit(90000)) { $process.Kill(); throw 'Packaged self-test timed out' }
    if ($process.ExitCode -ne 0) { throw "Packaged self-test failed: $($process.ExitCode)" }
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'PREVIEW.txt') -Destination $bundle
    # Collect third-party notices supplied with the Python environment; build-only dependencies are not shipped wholesale.
    $base = & $python -c 'import sys; print(sys.base_prefix)'
    if ($LASTEXITCODE -ne 0) { throw 'Unable to identify Python installation' }
    $license = Join-Path $base 'LICENSE.txt'
    if (-not (Test-Path -LiteralPath $license)) { throw 'Python license missing' }
    Copy-Item -LiteralPath $license -Destination (Join-Path $bundle 'PYTHON-LICENSE.txt')
    $notices = Join-Path $bundle 'NOTICES'
    New-Item -ItemType Directory -Path $notices | Out-Null
    $i = 0
    Get-ChildItem -LiteralPath (Join-Path $base 'tcl') -Recurse -File | Where-Object { $_.Name -match '^(license|license\.terms|license\.txt)$' } | ForEach-Object {
        $i++; Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $notices "tcl-tk-$i-$($_.Name)")
    }
    # Retain build tool versions and supplied package notices for review.
    Invoke-Checked $python @((Join-Path $PSScriptRoot 'collect-notices.py'),$notices)
    & $python -m pip freeze --all | Set-Content -LiteralPath (Join-Path $stage 'build-dependencies.txt') -Encoding ascii
    if ($LASTEXITCODE -ne 0) { throw 'Failed to record build dependencies' }
    $zip = Join-Path $stage "Aeris-$version-Windows-x64-portable.zip"
    Invoke-Checked $python @('-m','aeris.release_check','pack',$bundle,$zip)
    $artifacts = @($zip)
    if (-not $PortableOnly) {
        if (-not $Iscc) {
            $candidates = @((Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe'),(Join-Path $env:LOCALAPPDATA 'Programs\Inno Setup 6\ISCC.exe'))
            $Iscc = $candidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
        }
        if (-not $Iscc -or -not (Test-Path -LiteralPath $Iscc -PathType Leaf)) { throw 'Inno Setup ISCC.exe not found; use -Iscc or -PortableOnly.' }
        Invoke-Checked $Iscc @("/DAppVersion=$version","/DBundleDir=$bundle","/O$stage",(Join-Path $PSScriptRoot 'Aeris.iss'))
        $setup = Join-Path $stage "Aeris-$version-Windows-x64-Setup.exe"
        if (-not (Test-Path -LiteralPath $setup -PathType Leaf)) { throw 'Missing installer' }
        $artifacts += $setup
    }
    $hashes = foreach ($path in $artifacts) { $h = Get-FileHash -LiteralPath $path -Algorithm SHA256; "$($h.Hash.ToLowerInvariant())  $(Split-Path -Leaf $path)" }
    $hashes | Set-Content -LiteralPath (Join-Path $stage 'SHA256SUMS.txt') -Encoding ascii
    $verifyArgs = @('-m','aeris.release_check','verify',$stage,$version)
    if ($PortableOnly) { $verifyArgs += '--portable-only' }
    Invoke-Checked $python $verifyArgs
    (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant() | Set-Content -LiteralPath (Join-Path $stage 'AERIS-EXE-SHA256.txt') -Encoding ascii
    Write-Host "Build outputs (unsigned preview): $stage"
} finally { Pop-Location }
