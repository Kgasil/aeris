"""Explicit, cancellable CSV profiling with no write operations."""
import queue
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from aeris.permissions import DATA_READ
from aeris.data import profile_file, Cancelled
from aeris.organizer import safe_name
from pathlib import Path

class DataWindow:
    permission=DATA_READ
    title="Aeris Data"
    description="Perfil de qualidade de CSV local. Cabeçalho obrigatório. Use exemplos fictícios."
    def parse(self,path,delimiter,decimal,cancelled):
        return profile_file(path,delimiter,decimal,cancelled=cancelled)
    def __init__(self,hub):
        self.hub=hub; self.job=None; self.timer=None; self.path=None
        self.window=tk.Toplevel(hub.root); self.window.title(self.title); self.window.geometry('680x520'); self.window.minsize(510,460)
        self.window.protocol('WM_DELETE_WINDOW',self.close); self.window.bind('<Escape>',lambda _:self.close())
        self.window.bind('<Destroy>',self.destroyed,add='+')
        f=ttk.Frame(self.window,padding=14); f.pack(fill='both',expand=True)
        ttk.Label(f,text=self.title,font=('Segoe UI',18)).pack(anchor='w')
        ttk.Label(f,text=self.description,wraplength=460).pack(anchor='w',pady=5)
        self.choose_button=ttk.Button(f,text='Selecionar CSV local',command=self.choose); self.choose_button.pack(fill='x')
        self.filename=tk.StringVar(self.window,'Nenhum CSV selecionado'); ttk.Label(f,textvariable=self.filename,wraplength=460).pack(anchor='w',pady=4)
        opts=ttk.Frame(f); opts.pack(fill='x',pady=4)
        self.delimiter=tk.StringVar(self.window,','); self.decimal=tk.StringVar(self.window,'.')
        ttk.Label(opts,text='Separador de campos').pack(side='left')
        self.delim_box=ttk.Combobox(opts,textvariable=self.delimiter,values=(',', ';', 'TAB'),state='readonly',width=5); self.delim_box.pack(side='left',padx=6)
        ttk.Label(opts,text='Decimal').pack(side='left')
        self.dec_box=ttk.Combobox(opts,textvariable=self.decimal,values=('.', ','),state='readonly',width=5); self.dec_box.pack(side='left',padx=6)
        for widget in (self.delim_box,self.dec_box): widget.bind('<<ComboboxSelected>>',lambda _:self.show('Resultado pendente.'))
        self.run_button=ttk.Button(f,text='Analisar CSV',command=self.run); self.run_button.pack(fill='x',pady=6)
        self.cancel_button=ttk.Button(f,text='Cancelar',command=self.cancel); self.cancel_button.pack(fill='x',pady=4)
        frame=ttk.Frame(f); frame.pack(fill='both',expand=True,pady=5)
        self.report=tk.Text(frame,height=10,wrap='word',state='disabled'); self.report.pack(side='left',fill='both',expand=True)
        bar=ttk.Scrollbar(frame,command=self.report.yview); bar.pack(side='right',fill='y'); self.report.configure(yscrollcommand=bar.set)
        ttk.Button(f,text='Limpar resultado',command=self.clear).pack(fill='x')
        self.permissions_changed()
    def show(self,text):
        self.report.configure(state='normal'); self.report.delete('1.0','end'); self.report.insert('1.0',text); self.report.configure(state='disabled')
    def controls(self):
        allowed=self.hub.permissions.allowed(self.permission); busy=self.job is not None
        self.choose_button.configure(state='normal' if allowed and not busy else 'disabled')
        self.run_button.configure(state='normal' if allowed and not busy and self.path else 'disabled')
        self.cancel_button.configure(state='normal' if busy else 'disabled')
        for widget in (self.delim_box,self.dec_box): widget.configure(state='readonly' if allowed and not busy else 'disabled')
    def permissions_changed(self):
        if not self.hub.permissions.allowed(self.permission): self.clear(); self.show(f'Autorize {self.title} → Ler CSV em Permissões.')
        self.controls()
    def choose(self):
        if self.job or not self.hub.permissions.allowed(self.permission): return
        value=filedialog.askopenfilename(parent=self.window,title='Selecione CSV fictício',filetypes=[('CSV','*.csv')])
        if value and self.hub.permissions.allowed(self.permission):
            self.path=value; self.filename.set(safe_name(Path(value).name)); self.show('Resultado pendente.'); self.controls()
    def run(self):
        if self.job or not self.path or not self.hub.permissions.allowed(self.permission): return
        if not messagebox.askyesno('Analisar CSV?', 'Ler o CSV selecionado para calcular estatísticas? O relatório pode revelar dados pessoais.',parent=self.window): return
        if not self.window.winfo_exists() or not self.path or not self.hub.permissions.allowed(self.permission): return
        event=threading.Event(); outcome=queue.Queue(1); path=self.path; delimiter="\t" if self.delimiter.get()=="TAB" else self.delimiter.get(); decimal=self.decimal.get()
        def work():
            try: outcome.put(self.parse(path,delimiter,decimal,event.is_set))
            except Cancelled: outcome.put(None)
            except ValueError as exc: outcome.put(str(exc))
            except Exception: outcome.put('Não foi possível analisar o CSV.')
        self.job=(event,outcome); self.controls(); self.show('Analisando CSV...')
        threading.Thread(target=work,daemon=True).start(); self.poll()
    def poll(self):
        self.timer=None
        if self.job is None: return
        event,outcome=self.job
        try: result=outcome.get_nowait()
        except queue.Empty: self.timer=self.window.after(60,self.poll); return
        self.job=None; self.controls()
        if event.is_set() or not self.hub.permissions.allowed(self.permission): return
        if isinstance(result,str): self.show(result); return
        if result is None: self.show('Cancelado.'); return
        self.render_result(result)
    def render_result(self,result):
        lines=[f'Registros: {result.rows} | Colunas: {len(result.columns)}',f'Valores ausentes: {result.missing} | Duplicatas exatas adicionais: {result.duplicates}', 'Inferência numérica simples; confira identificadores e separadores.']
        for col in result.columns:
            lines.append(f'\n{safe_name(col.name)} | {col.kind} | Ausentes: {col.missing} | Distintos: {col.distinct}')
            if col.mean is not None: lines.append(f' Mín: {col.minimum} | Máx: {col.maximum} | Média: {col.mean:.10g}')
        self.show('\n'.join(lines))
    def cancel(self):
        if self.job: self.job[0].set(); self.show('Cancelamento solicitado; resultado descartado.')
    def clear(self):
        self.cancel(); self.path=None; self.filename.set('Nenhum CSV selecionado'); self.show('Resultado descartado.'); self.controls()
    def destroyed(self,event):
        if event.widget is self.window:
            if self.job: self.job[0].set()
            if self.timer is not None: self.window.after_cancel(self.timer); self.timer=None
    def close(self):
        self.cancel(); self.window.destroy()
