"""Read-only, bounded-memory file hashing. No trust verdict or signature check."""
from dataclasses import dataclass
import hashlib
import hmac
import os
from pathlib import Path
import re
import stat

ALGORITHMS = {'SHA-256': 'sha256', 'SHA-512': 'sha512'}
CHUNK = 1024 * 1024
class Cancelled(Exception): pass

@dataclass(frozen=True)
class HashResult:
    algorithm: str
    digest: str
    size: int
    matches: bool | None

def expected_hash(algorithm, value):
    if algorithm not in ALGORITHMS: raise ValueError('Algoritmo não suportado.')
    value = value.strip().lower()
    if value and not re.fullmatch('[0-9a-f]{%d}' % (64 if algorithm == 'SHA-256' else 128), value):
        raise ValueError('Hash esperado deve conter somente dígitos hexadecimais na extensão correta.')
    return value

def _local_path(path):
    p = Path(path)
    if os.name == 'nt':
        import ctypes
        # Refuse UNC/device paths and non-fixed drives before opening.
        if not p.is_absolute() or any(':' in part or part == '..' for part in p.parts[1:]) or not re.fullmatch(r'[a-zA-Z]:', p.drive) or ctypes.windll.kernel32.GetDriveTypeW(p.anchor) != 3:
            raise ValueError('Selecione um arquivo em uma unidade local fixa.')
        for parent in reversed(p.parents):
            if getattr(parent.lstat(), 'st_file_attributes', 0) & 0x400:
                raise ValueError('Caminhos com pontos de nova análise não são aceitos.')
    return p

def _stamp(st):
    return st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns

def hash_file(path, algorithm, expected='', *, cancelled=lambda:False, progress=lambda done,total:None):
    expected = expected_hash(algorithm, expected)
    if cancelled(): raise Cancelled()
    p = _local_path(path)
    # Reject final symlinks/reparse points and non-regular files before open.
    pre = p.lstat()
    if not stat.S_ISREG(pre.st_mode) or getattr(pre, 'st_file_attributes', 0) & 0x400:
        raise ValueError('Somente arquivos regulares, sem links simbólicos ou pontos de nova análise.')
    flags = os.O_RDONLY | getattr(os,'O_BINARY',0) | getattr(os,'O_NONBLOCK',0) | getattr(os,'O_NOFOLLOW',0)
    fd = os.open(p,flags)
    with os.fdopen(fd,'rb') as stream:
        initial = os.fstat(stream.fileno())
        if not stat.S_ISREG(initial.st_mode) or _stamp(pre) != _stamp(initial):
            raise ValueError('Arquivo alterado antes da leitura.')
        digest = hashlib.new(ALGORITHMS[algorithm]); done = 0
        progress(done,initial.st_size)
        while True:
            if cancelled(): raise Cancelled()
            block = stream.read(CHUNK)
            if not block: break
            done += len(block)
            if done > initial.st_size: raise ValueError('Arquivo alterado durante a leitura.')
            digest.update(block); progress(done,initial.st_size)
        if cancelled(): raise Cancelled()
        if done != initial.st_size or _stamp(initial) != _stamp(os.fstat(stream.fileno())) or _stamp(initial) != _stamp(p.lstat()):
            raise ValueError('Arquivo alterado durante a leitura; resultado descartado.')
    value = digest.hexdigest()
    return HashResult(algorithm,value,done,hmac.compare_digest(value,expected) if expected else None)
